<?php

    session_start();
    if(!isset($_SESSION['user_login'])){
        header('Location: login.php');
    }

    include __DIR__ .'/model/model_police.php';
    include __DIR__ .'/model/functions.php';

    
    $listAnnouncements = listAnnouncements();
    $deleteAnnouncements = deleteAnnouncement();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" type="text/css" href="css/normalize.css" />
    <title>R&T Police Department</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> <!-- bootsrap -->
    <link rel="stylesheet" type="text/css" href="css/style.css" />

</head>

<body>

    <div class="wrapper">
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
            <a class="navbar-brand" href="#">RTPD</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    
                    <li class="nav-item"><a class="nav-link" href="user_announcements.php">Announcements</a></li>

                    <li class="nav-item"><a class="nav-link" href="user_case_details.php">Case Details</a></li>

                    <li class="nav-item"><a class="nav-link" href="user_messages.php">Messages</a></li>
                                        
                </ul>
            </div>
        </nav>

        <main>
            <article>
            <div class="box-container">
                <h1 class="main-heading">Announcements</h1>
            </div>
            <div class="box-container">
                <div class="black-box-announcement">
                    <?php foreach ($listAnnouncements as $row): ?>
                        <form action="admin_announcements.php" method="post">
                            <input type="hidden" name="announcement_id" value="<?php echo $row['announcement_id']; ?>" />
                                <div class="announcements container">
                                    <h2 class="row col"><?php echo $row['announcement_title']; ?></h2>
                                    <p class="row col"><?php echo $row['announcement']; ?></p>
                    <span class="row col">Posted By: &lt;<?php foreach($employees as $employee): ?><?php if($row['employee_id'] == $employee['employee_id']): ?><?php echo $row['employee_id']; ?><?php endif; ?><?php endforeach; ?>&gt; on &lt;<?php echo $row['post_time']; ?>&gt;</span><br>
                                </div>
                            <br><br>
                        </form>
                    <?php endforeach; ?>
                </div>
            </div>
            </article>
        </main>

        <footer class="section-2">
            <img class="emblem-badge" src="images/RTPD-emblem-210.png" alt="R&TPD Emblem">
            <img class="emblem-badge" src="images/RTPD-badge-210.png" alt="R&TPD Badge">
            <div class="address">
                <h3>Location</h3>
                <p>4420 Main Street</p>
                <p>New York, New York</p>
                <br>

                <br>
                <a class="footer-link" href="login.php">Back to Login</a>
            </div>
        </footer>
</body>

</html>